package lesson20.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JBoardDao {
	   
    PreparedStatement pstmt = null;
    Statement stmt = null;
    ResultSet res = null;
    Connection conn;
    
    public JBoardDao(Connection conn) {
       this.conn = conn;
    }
    
 //db�� ����
 public int insertDB(Connection conn, String title, String content, String writer) {
    int id = 0;
    PreparedStatement pstmt = null;
    String sql = "insert into jboard(title, content, writer) "
          + "values (?, ?, ?)";
    try {
       pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
       pstmt.setString(1, title);
       pstmt.setString(2, content);
       pstmt.setString(3, writer);
       pstmt.executeUpdate();
       
       ResultSet res = pstmt.getGeneratedKeys(); //������ ����� �� ������ Ű���� ��ȯ
       if(res.next()) {
          id =  res.getInt(1);
       }
       sql = "update 1 set rfid=? where id=?";
       pstmt = conn.prepareStatement(sql);
       pstmt.setInt(1, id);
       pstmt.setInt(2, id);
       pstmt.executeUpdate();
       
       System.out.println(id);
    } catch (SQLException e) {
       e.printStackTrace();
    }
    return id;
 }
    //db ����
    public int updateDB(String title, String content, String writer, int id) {
       int rs = 0;
       String sql = "update jboard set title=?, content=? , writer=? where id=?";
       try {
          pstmt = conn.prepareStatement(sql);
          pstmt.setString(1, title);
          pstmt.setString(2, content);
          pstmt.setString(3, writer);
          pstmt.setInt(4, id);
          rs = pstmt.executeUpdate();
          
       } catch (SQLException e) {
          e.printStackTrace();
       } finally {
          try {
             if(pstmt != null)pstmt.close();
          } catch (SQLException e) {
             e.printStackTrace();
          }
       }
       return rs;
    }
    
    //db ����
    public int deleteDB(int id) {
       int rs = 0;
       String sql = "delete from jboard where id=?";
       try {
          pstmt = conn.prepareStatement(sql);
          pstmt.setInt(1, id);
          rs = pstmt.executeUpdate();
       } catch (SQLException e) {
          e.printStackTrace();
       } finally {
          try {
             if(pstmt != null)pstmt.close();
          } catch (SQLException e) {
             e.printStackTrace();
          }
       }
       
       return rs;
    }
       
    
    
    //db �˻�
    public void select() {
       String sql = "select * from jboard order by refid desc, renum asc";
       try {
          stmt = conn.createStatement();
          res = stmt.executeQuery(sql);
          while(res.next()) {
             System.out.println(res.getInt("id") + " , " + res.getString("title"));
             
          }
       } catch (SQLException e) {
          // TODO Auto-generated catch block
          e.printStackTrace();
       }
    }
    
}
 
 
 
 
 
 
