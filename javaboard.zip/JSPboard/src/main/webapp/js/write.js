$(function(){
//글쓰기 링크
    $("#contents").summernote({
        placeholder: "내용",
        tabsize: 2,
        height: 300,
        lang: 'ko-KR'        
    });
});
